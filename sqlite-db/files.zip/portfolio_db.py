#!/usr/bin/env python3
"""
Modern SQLite Portfolio Database Manager
Fast, efficient operations with best practices
"""

import sqlite3
from contextlib import contextmanager
from datetime import datetime
from typing import List, Dict, Optional
import json
from pathlib import Path


class PortfolioDB:
    """Fast and modern SQLite database manager for creative portfolio"""
    
    def __init__(self, db_path: str = "portfolio.db"):
        self.db_path = db_path
        self.connection = None
        
    @contextmanager
    def get_connection(self):
        """Context manager for database connections"""
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row  # Return rows as dictionaries
        conn.execute("PRAGMA foreign_keys = ON")
        conn.execute("PRAGMA journal_mode = WAL")
        try:
            yield conn
            conn.commit()
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()
    
    def initialize_database(self, schema_path: str = "portfolio_schema.sql"):
        """Initialize database from schema file"""
        with self.get_connection() as conn:
            with open(schema_path, 'r') as f:
                conn.executescript(f.read())
        print(f"✓ Database initialized at {self.db_path}")
    
    # ========================================================================
    # PROJECT OPERATIONS
    # ========================================================================
    
    def add_project(
        self,
        title: str,
        slug: str,
        description: str,
        project_type: str,
        category: str,
        client: Optional[str] = None,
        year: Optional[int] = None,
        featured: bool = False,
        metadata: Optional[Dict] = None
    ) -> int:
        """Add a new project - returns project ID"""
        with self.get_connection() as conn:
            cursor = conn.execute(
                """
                INSERT INTO projects 
                (title, slug, description, type, category, client, year, featured, metadata)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    title, slug, description, project_type, category,
                    client, year, int(featured),
                    json.dumps(metadata) if metadata else None
                )
            )
            return cursor.lastrowid
    
    def get_project(self, project_id: int) -> Optional[Dict]:
        """Get project by ID with all media and tags"""
        with self.get_connection() as conn:
            # Get project
            project = conn.execute(
                "SELECT * FROM projects WHERE id = ?", (project_id,)
            ).fetchone()
            
            if not project:
                return None
            
            project_dict = dict(project)
            
            # Get media
            media = conn.execute(
                """
                SELECT * FROM media 
                WHERE project_id = ? 
                ORDER BY display_order, created_at
                """,
                (project_id,)
            ).fetchall()
            project_dict['media'] = [dict(m) for m in media]
            
            # Get tags
            tags = conn.execute(
                """
                SELECT t.* FROM tags t
                JOIN project_tags pt ON t.id = pt.tag_id
                WHERE pt.project_id = ?
                """,
                (project_id,)
            ).fetchall()
            project_dict['tags'] = [dict(t) for t in tags]
            
            return project_dict
    
    def get_all_projects(self, featured_only: bool = False) -> List[Dict]:
        """Get all projects (optionally featured only)"""
        with self.get_connection() as conn:
            query = "SELECT * FROM projects_summary"
            if featured_only:
                query += " WHERE featured = 1"
            query += " ORDER BY display_order, created_at DESC"
            
            projects = conn.execute(query).fetchall()
            return [dict(p) for p in projects]
    
    def get_projects_by_category(self, category: str) -> List[Dict]:
        """Get projects filtered by category"""
        with self.get_connection() as conn:
            projects = conn.execute(
                """
                SELECT * FROM projects_summary 
                WHERE category = ?
                ORDER BY display_order, created_at DESC
                """,
                (category,)
            ).fetchall()
            return [dict(p) for p in projects]
    
    def search_projects(self, query: str) -> List[Dict]:
        """Search projects by title or description"""
        with self.get_connection() as conn:
            search_term = f"%{query}%"
            projects = conn.execute(
                """
                SELECT * FROM projects_summary 
                WHERE title LIKE ? OR description LIKE ?
                ORDER BY featured DESC, created_at DESC
                """,
                (search_term, search_term)
            ).fetchall()
            return [dict(p) for p in projects]
    
    # ========================================================================
    # MEDIA OPERATIONS
    # ========================================================================
    
    def add_media(
        self,
        project_id: int,
        file_path: str,
        media_type: str,
        thumbnail_path: Optional[str] = None,
        alt_text: Optional[str] = None,
        is_cover: bool = False,
        width: Optional[int] = None,
        height: Optional[int] = None,
        duration: Optional[int] = None
    ) -> int:
        """Add media to a project - returns media ID"""
        with self.get_connection() as conn:
            cursor = conn.execute(
                """
                INSERT INTO media 
                (project_id, file_path, thumbnail_path, media_type, alt_text, 
                 is_cover, width, height, duration)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    project_id, file_path, thumbnail_path, media_type,
                    alt_text, int(is_cover), width, height, duration
                )
            )
            return cursor.lastrowid
    
    def get_project_media(self, project_id: int) -> List[Dict]:
        """Get all media for a project"""
        with self.get_connection() as conn:
            media = conn.execute(
                """
                SELECT * FROM media 
                WHERE project_id = ? 
                ORDER BY display_order, created_at
                """,
                (project_id,)
            ).fetchall()
            return [dict(m) for m in media]
    
    # ========================================================================
    # TAG OPERATIONS
    # ========================================================================
    
    def add_tag(self, name: str, slug: str) -> int:
        """Add a new tag - returns tag ID"""
        with self.get_connection() as conn:
            cursor = conn.execute(
                "INSERT INTO tags (name, slug) VALUES (?, ?)",
                (name, slug)
            )
            return cursor.lastrowid
    
    def tag_project(self, project_id: int, tag_id: int):
        """Associate a tag with a project"""
        with self.get_connection() as conn:
            conn.execute(
                "INSERT OR IGNORE INTO project_tags (project_id, tag_id) VALUES (?, ?)",
                (project_id, tag_id)
            )
    
    def get_popular_tags(self, limit: int = 10) -> List[Dict]:
        """Get most used tags"""
        with self.get_connection() as conn:
            tags = conn.execute(
                """
                SELECT * FROM tags 
                WHERE usage_count > 0 
                ORDER BY usage_count DESC 
                LIMIT ?
                """,
                (limit,)
            ).fetchall()
            return [dict(t) for t in tags]
    
    def get_projects_by_tag(self, tag_slug: str) -> List[Dict]:
        """Get all projects with a specific tag"""
        with self.get_connection() as conn:
            projects = conn.execute(
                """
                SELECT p.* FROM projects_summary p
                JOIN project_tags pt ON p.id = pt.project_id
                JOIN tags t ON pt.tag_id = t.id
                WHERE t.slug = ?
                ORDER BY p.display_order, p.created_at DESC
                """,
                (tag_slug,)
            ).fetchall()
            return [dict(p) for p in projects]
    
    # ========================================================================
    # UTILITY OPERATIONS
    # ========================================================================
    
    def optimize_database(self):
        """Run optimization commands"""
        with self.get_connection() as conn:
            conn.execute("ANALYZE")
            conn.execute("VACUUM")
        print("✓ Database optimized")
    
    def get_stats(self) -> Dict:
        """Get portfolio statistics"""
        with self.get_connection() as conn:
            stats = {
                'total_projects': conn.execute("SELECT COUNT(*) FROM projects").fetchone()[0],
                'featured_projects': conn.execute("SELECT COUNT(*) FROM projects WHERE featured = 1").fetchone()[0],
                'total_media': conn.execute("SELECT COUNT(*) FROM media").fetchone()[0],
                'total_tags': conn.execute("SELECT COUNT(*) FROM tags").fetchone()[0],
                'projects_by_type': dict(
                    conn.execute("SELECT type, COUNT(*) FROM projects GROUP BY type").fetchall()
                ),
                'projects_by_category': dict(
                    conn.execute("SELECT category, COUNT(*) FROM projects GROUP BY category").fetchall()
                )
            }
            return stats


# ============================================================================
# EXAMPLE USAGE
# ============================================================================

if __name__ == "__main__":
    # Initialize database
    db = PortfolioDB("portfolio.db")
    db.initialize_database("portfolio_schema.sql")
    
    # Add a project
    project_id = db.add_project(
        title="Minimalist Logo Design",
        slug="minimalist-logo-design",
        description="Clean and modern logo for a sustainable fashion brand",
        project_type="image",
        category="branding",
        client="EcoWear",
        year=2024,
        featured=True,
        metadata={"tools": ["Adobe Illustrator", "Figma"], "duration": "2 weeks"}
    )
    print(f"✓ Created project ID: {project_id}")
    
    # Add media
    media_id = db.add_media(
        project_id=project_id,
        file_path="/images/ecowear/logo-final.png",
        thumbnail_path="/images/ecowear/logo-final_thumb.jpg",
        media_type="image",
        alt_text="EcoWear minimalist logo",
        is_cover=True,
        width=2000,
        height=2000
    )
    print(f"✓ Added media ID: {media_id}")
    
    # Add tags
    tag_id = db.add_tag("minimalist", "minimalist")
    db.tag_project(project_id, tag_id)
    print(f"✓ Tagged project")
    
    # Get project with all details
    project = db.get_project(project_id)
    print(f"\n✓ Project: {project['title']}")
    print(f"  Media files: {len(project['media'])}")
    print(f"  Tags: {len(project['tags'])}")
    
    # Get statistics
    stats = db.get_stats()
    print(f"\n✓ Portfolio Stats:")
    print(f"  Total projects: {stats['total_projects']}")
    print(f"  Featured: {stats['featured_projects']}")
    print(f"  Media files: {stats['total_media']}")
    
    # Optimize
    db.optimize_database()
