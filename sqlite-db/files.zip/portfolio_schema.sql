-- ============================================================================
-- MODERN CREATIVE PORTFOLIO DATABASE SCHEMA
-- Optimized for SQLite with performance indexes and modern features
-- ============================================================================

-- Enable foreign keys (important for SQLite!)
PRAGMA foreign_keys = ON;

-- Enable Write-Ahead Logging for better concurrency
PRAGMA journal_mode = WAL;

-- ============================================================================
-- PROJECTS TABLE - Core portfolio items
-- ============================================================================
CREATE TABLE projects (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    slug TEXT NOT NULL UNIQUE, -- URL-friendly, indexed for fast lookups
    description TEXT,
    type TEXT NOT NULL CHECK(type IN ('image', 'video', 'mixed')), -- Project type
    client TEXT,
    year INTEGER,
    category TEXT NOT NULL, -- 'branding', 'motion', 'web', 'print', etc.
    featured INTEGER DEFAULT 0 CHECK(featured IN (0, 1)), -- Boolean as int
    display_order INTEGER DEFAULT 0,
    metadata TEXT, -- JSON field for flexible data (tools, dimensions, etc.)
    created_at TEXT DEFAULT (datetime('now')),
    updated_at TEXT DEFAULT (datetime('now'))
);

-- Indexes for fast queries
CREATE INDEX idx_projects_featured ON projects(featured) WHERE featured = 1;
CREATE INDEX idx_projects_category ON projects(category);
CREATE INDEX idx_projects_year ON projects(year DESC);
CREATE INDEX idx_projects_type ON projects(type);
CREATE INDEX idx_projects_display_order ON projects(display_order);

-- ============================================================================
-- MEDIA TABLE - Images and videos for projects
-- ============================================================================
CREATE TABLE media (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    project_id INTEGER NOT NULL,
    file_path TEXT NOT NULL, -- Relative path to file
    thumbnail_path TEXT, -- Optimized thumbnail
    media_type TEXT NOT NULL CHECK(media_type IN ('image', 'video')),
    alt_text TEXT, -- Accessibility
    width INTEGER, -- Image/video dimensions
    height INTEGER,
    duration INTEGER, -- For videos (in seconds)
    file_size INTEGER, -- In bytes
    is_cover INTEGER DEFAULT 0 CHECK(is_cover IN (0, 1)), -- Main project image
    display_order INTEGER DEFAULT 0,
    created_at TEXT DEFAULT (datetime('now')),
    FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE
);

-- Indexes for fast queries
CREATE INDEX idx_media_project ON media(project_id);
CREATE INDEX idx_media_type ON media(media_type);
CREATE INDEX idx_media_cover ON media(project_id, is_cover) WHERE is_cover = 1;
CREATE INDEX idx_media_order ON media(project_id, display_order);

-- ============================================================================
-- TAGS TABLE - Flexible categorization
-- ============================================================================
CREATE TABLE tags (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL UNIQUE,
    slug TEXT NOT NULL UNIQUE,
    usage_count INTEGER DEFAULT 0, -- Denormalized for performance
    created_at TEXT DEFAULT (datetime('now'))
);

CREATE INDEX idx_tags_slug ON tags(slug);
CREATE INDEX idx_tags_usage ON tags(usage_count DESC);

-- ============================================================================
-- PROJECT_TAGS TABLE - Many-to-many relationship
-- ============================================================================
CREATE TABLE project_tags (
    project_id INTEGER NOT NULL,
    tag_id INTEGER NOT NULL,
    created_at TEXT DEFAULT (datetime('now')),
    PRIMARY KEY (project_id, tag_id),
    FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE,
    FOREIGN KEY (tag_id) REFERENCES tags(id) ON DELETE CASCADE
);

CREATE INDEX idx_project_tags_tag ON project_tags(tag_id);

-- ============================================================================
-- TRIGGERS - Auto-update timestamps and denormalized counts
-- ============================================================================

-- Update projects.updated_at on any change
CREATE TRIGGER update_project_timestamp 
AFTER UPDATE ON projects
BEGIN
    UPDATE projects SET updated_at = datetime('now') WHERE id = NEW.id;
END;

-- Update tag usage count when project_tags changes
CREATE TRIGGER increment_tag_count
AFTER INSERT ON project_tags
BEGIN
    UPDATE tags SET usage_count = usage_count + 1 WHERE id = NEW.tag_id;
END;

CREATE TRIGGER decrement_tag_count
AFTER DELETE ON project_tags
BEGIN
    UPDATE tags SET usage_count = usage_count - 1 WHERE id = OLD.tag_id;
END;

-- Ensure only one cover image per project
CREATE TRIGGER enforce_single_cover
BEFORE INSERT ON media
WHEN NEW.is_cover = 1
BEGIN
    UPDATE media SET is_cover = 0 WHERE project_id = NEW.project_id;
END;

-- ============================================================================
-- VIEWS - Common queries optimized
-- ============================================================================

-- Featured projects with cover images
CREATE VIEW featured_projects AS
SELECT 
    p.*,
    m.file_path as cover_image,
    m.thumbnail_path as cover_thumbnail,
    GROUP_CONCAT(t.name, ', ') as tags
FROM projects p
LEFT JOIN media m ON p.id = m.project_id AND m.is_cover = 1
LEFT JOIN project_tags pt ON p.id = pt.project_id
LEFT JOIN tags t ON pt.tag_id = t.id
WHERE p.featured = 1
GROUP BY p.id
ORDER BY p.display_order, p.created_at DESC;

-- All projects with their media count
CREATE VIEW projects_summary AS
SELECT 
    p.*,
    COUNT(DISTINCT m.id) as media_count,
    GROUP_CONCAT(DISTINCT t.name, ', ') as tags,
    (SELECT file_path FROM media WHERE project_id = p.id AND is_cover = 1 LIMIT 1) as cover_image
FROM projects p
LEFT JOIN media m ON p.id = m.project_id
LEFT JOIN project_tags pt ON p.id = pt.project_id
LEFT JOIN tags t ON pt.tag_id = t.id
GROUP BY p.id
ORDER BY p.display_order, p.created_at DESC;

-- ============================================================================
-- SAMPLE DATA - Example entries to get started
-- ============================================================================

INSERT INTO projects (title, slug, description, type, client, year, category, featured, display_order) VALUES
('Brand Identity Redesign', 'brand-identity-redesign', 'Complete visual identity system for a tech startup', 'image', 'TechCorp', 2024, 'branding', 1, 1),
('Motion Graphics Reel', 'motion-graphics-reel', 'Showreel of motion design work', 'video', NULL, 2024, 'motion', 1, 2),
('Product Launch Campaign', 'product-launch-campaign', 'Multi-channel campaign including print and digital', 'mixed', 'RetailBrand', 2023, 'campaign', 0, 3);

INSERT INTO tags (name, slug) VALUES
('minimalist', 'minimalist'),
('colorful', 'colorful'),
('3d', '3d'),
('typography', 'typography'),
('animation', 'animation');

INSERT INTO media (project_id, file_path, thumbnail_path, media_type, alt_text, is_cover, display_order) VALUES
(1, '/images/projects/brand-identity/logo.jpg', '/images/projects/brand-identity/logo_thumb.jpg', 'image', 'TechCorp logo design', 1, 1),
(1, '/images/projects/brand-identity/colors.jpg', '/images/projects/brand-identity/colors_thumb.jpg', 'image', 'Brand color palette', 0, 2),
(2, '/videos/motion-reel-2024.mp4', '/videos/motion-reel-2024_thumb.jpg', 'video', 'Motion graphics showreel', 1, 1);

INSERT INTO project_tags (project_id, tag_id) VALUES
(1, 1), -- Brand Identity + minimalist
(1, 4), -- Brand Identity + typography
(2, 3), -- Motion Graphics + 3d
(2, 5); -- Motion Graphics + animation

-- ============================================================================
-- OPTIMIZATION TIPS
-- ============================================================================
-- 1. Run ANALYZE periodically to update query planner statistics
-- 2. Use VACUUM to reclaim space and defragment
-- 3. For production, consider setting:
--    PRAGMA cache_size = -64000; (64MB cache)
--    PRAGMA temp_store = MEMORY;
-- 4. Store metadata as JSON in the metadata column for flexibility
-- 5. Use slugs instead of IDs in URLs for SEO
-- ============================================================================
