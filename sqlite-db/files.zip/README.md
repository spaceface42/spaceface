# Modern Creative Portfolio Database

A fast, optimized SQLite database for graphic design and motion graphics portfolios.

## Features ✨

- **Minimal & Fast** - Only 4 core tables, optimized indexes
- **Flexible Media** - Handles both images and videos seamlessly
- **Smart Tagging** - Organize projects with reusable tags
- **Performance-First** - WAL mode, strategic indexes, materialized views
- **Modern Design** - JSON metadata, slugs for SEO, automatic timestamps

## Quick Start 🚀

### 1. Initialize the Database

```bash
# Using SQLite directly
sqlite3 portfolio.db < portfolio_schema.sql

# Or using Python
python3 portfolio_db.py
```

### 2. Connect from Your App

**Python:**
```python
from portfolio_db import PortfolioDB

db = PortfolioDB("portfolio.db")

# Add a project
project_id = db.add_project(
    title="Brand Identity",
    slug="brand-identity-2024",
    description="Complete rebrand",
    project_type="image",
    category="branding",
    featured=True
)

# Get all featured projects
featured = db.get_all_projects(featured_only=True)
```

**Node.js/JavaScript:**
```javascript
const sqlite3 = require('sqlite3').verbose();
const db = new sqlite3.Database('portfolio.db');

// Get featured projects
db.all(`SELECT * FROM featured_projects`, [], (err, rows) => {
  console.log(rows);
});
```

**PHP:**
```php
$db = new PDO('sqlite:portfolio.db');

// Get project
$stmt = $db->prepare('SELECT * FROM projects_summary WHERE slug = ?');
$stmt->execute(['brand-identity-2024']);
$project = $stmt->fetch();
```

## Database Schema 📊

### Tables

**projects** - Your portfolio work
- Stores title, description, type (image/video/mixed), category, client
- Has featured flag and display_order for homepage
- JSON metadata field for flexible data (tools used, etc.)

**media** - Images and videos
- Links to projects (many-to-one)
- Stores file paths, thumbnails, dimensions
- One media item can be marked as cover image
- Supports both images and videos

**tags** - Reusable labels
- Simple name/slug structure
- Tracks usage count automatically

**project_tags** - Links projects to tags (many-to-many)

### Optimized Views

**featured_projects** - Ready-to-use homepage query
```sql
SELECT * FROM featured_projects;
```

**projects_summary** - All projects with media counts and cover images
```sql
SELECT * FROM projects_summary WHERE category = 'branding';
```

## Common Queries 📝

### Get Portfolio Homepage Data
```sql
SELECT * FROM featured_projects ORDER BY display_order LIMIT 6;
```

### Get Project Detail Page
```sql
-- Get project
SELECT * FROM projects WHERE slug = 'my-project';

-- Get all media for project
SELECT * FROM media WHERE project_id = ? ORDER BY display_order;

-- Get project tags
SELECT t.* FROM tags t
JOIN project_tags pt ON t.id = pt.tag_id
WHERE pt.project_id = ?;
```

### Filter by Category
```sql
SELECT * FROM projects_summary 
WHERE category = 'motion' 
ORDER BY year DESC;
```

### Filter by Tag
```sql
SELECT p.* FROM projects_summary p
JOIN project_tags pt ON p.id = pt.project_id
JOIN tags t ON pt.tag_id = t.id
WHERE t.slug = 'minimalist';
```

### Search Projects
```sql
SELECT * FROM projects_summary 
WHERE title LIKE '%logo%' OR description LIKE '%logo%';
```

### Get Popular Tags
```sql
SELECT * FROM tags 
WHERE usage_count > 0 
ORDER BY usage_count DESC 
LIMIT 10;
```

## Performance Tips ⚡

### 1. Indexes Are Already Set Up
The schema includes strategic indexes on:
- `featured` flag for homepage queries
- `category` for filtering
- `year` for timeline views
- `display_order` for sorting
- Foreign keys for joins

### 2. Use Prepared Statements
Always use parameterized queries to prevent SQL injection and improve performance:
```python
# Good ✓
cursor.execute("SELECT * FROM projects WHERE id = ?", (project_id,))

# Bad ✗
cursor.execute(f"SELECT * FROM projects WHERE id = {project_id}")
```

### 3. Use the Provided Views
Views like `featured_projects` and `projects_summary` are optimized for common queries.

### 4. Enable WAL Mode (Already Done)
```sql
PRAGMA journal_mode = WAL;
```
This allows concurrent reads while writing.

### 5. Periodic Maintenance
Run these occasionally:
```python
db.optimize_database()  # Python helper
```

Or directly:
```sql
ANALYZE;  -- Update query planner statistics
VACUUM;   -- Reclaim space and defragment
```

### 6. Cache Frequently Accessed Data
In your application layer, cache:
- Featured projects list
- Popular tags
- Categories list

### 7. Optimize Media Files
Store optimized thumbnails separately:
```
/images/
  /originals/project-1-image.jpg    (high-res)
  /thumbnails/project-1-image.jpg   (optimized)
```

## JSON Metadata Examples 💡

Store flexible data in the `metadata` column:

```json
{
  "tools": ["Illustrator", "After Effects"],
  "duration": "3 weeks",
  "deliverables": ["Logo", "Brand Guidelines", "Social Media Kit"],
  "colors": ["#FF6B6B", "#4ECDC4", "#45B7D1"],
  "awards": ["Awwwards SOTD", "CSS Design Awards"]
}
```

Query JSON data:
```sql
SELECT * FROM projects 
WHERE json_extract(metadata, '$.tools') LIKE '%Illustrator%';
```

## Example Categories 🎨

Common categories for graphic designers:
- `branding` - Logos, brand identities
- `motion` - Motion graphics, animations
- `web` - Web design, UI/UX
- `print` - Posters, brochures, packaging
- `editorial` - Magazine layouts, publications
- `illustration` - Custom illustrations
- `3d` - 3D renders, modeling

## Migration from Other Systems 🔄

### From WordPress
```python
# Export WordPress posts
# Import into projects table with category mapping
```

### From Behance/Dribbble
Parse your exported data and map:
- Project → projects
- Images → media (type='image')
- Tags → tags

## Backup Strategy 💾

SQLite databases are single files, making backups easy:

```bash
# Daily backup
cp portfolio.db backups/portfolio-$(date +%Y%m%d).db

# Or use SQLite backup command
sqlite3 portfolio.db ".backup backups/portfolio-backup.db"
```

## Troubleshooting 🔧

**Foreign keys not working?**
```sql
PRAGMA foreign_keys = ON;
```
Must be set for each connection.

**Slow queries?**
```sql
EXPLAIN QUERY PLAN SELECT * FROM projects WHERE category = 'branding';
```
Check if indexes are being used.

**Database locked?**
- Enable WAL mode (already in schema)
- Close connections properly
- Use connection pooling

## File Structure 📁

```
portfolio-db/
├── portfolio_schema.sql    # Database schema
├── portfolio_db.py         # Python helper class
├── portfolio.db           # Your database (created)
└── README.md              # This file
```

## License

Free to use for personal and commercial projects.

---

**Questions?** The Python helper class (`portfolio_db.py`) includes example usage and covers all common operations.
